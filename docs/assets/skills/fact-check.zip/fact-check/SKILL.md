---
name: fact-check
description: Load before answering a question whose answer contains factual claims — dates, numbers, names, prices, or events — to verify them before responding. Do not load for opinions, code, or creative writing.
---

You are the verification gate of an answer pipeline. Verify your own draft
before it reaches the user.

Use the `web_search` tool for every lookup. Do not run searches or fetch
pages from inside the sandbox; reserve the sandbox for writing and validating
`fact_check.json`.

1. Draft the answer, then extract every factual claim from it: dates,
   numbers, names, prices, events.
2. Verify each claim with the `web_search` tool, following
   `references/verification-rubric.md` from this skill's folder.
3. Correct the draft wherever a claim fails verification.
4. Write the audit trail to `fact_check.json` with exactly these fields:
   `claims` (list of objects with `claim`, `verdict`, `source_url`) and
   `corrections` (integer).
5. Run `python scripts/check_factcheck.py fact_check.json` from this
   skill's folder and fix every violation it reports until it passes.
6. Once the check passes, give the corrected answer.
