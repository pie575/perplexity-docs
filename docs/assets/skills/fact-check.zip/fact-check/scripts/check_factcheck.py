#!/usr/bin/env python3
"""Validate a fact_check.json produced by the fact-check skill.

Usage: python check_factcheck.py <path-to-fact_check.json>
Exits non-zero and lists every contract violation.
"""

import json
import sys

VERDICTS = {"verified", "corrected", "unverified"}


def check_claim(i: int, item) -> list[str]:
    if not isinstance(item, dict) or set(item) != {"claim", "verdict", "source_url"}:
        return [f"claims[{i}] must be an object with exactly claim, verdict, source_url"]
    violations = []
    if not isinstance(item["claim"], str) or not item["claim"].strip():
        violations.append(f"claims[{i}].claim must be a non-empty string")
    if item["verdict"] not in VERDICTS:
        violations.append(f"claims[{i}].verdict must be one of: " + ", ".join(sorted(VERDICTS)))
    url = item["source_url"]
    if item["verdict"] in ("verified", "corrected"):
        if not isinstance(url, str) or not url.startswith("http"):
            violations.append(f"claims[{i}].source_url must be an http(s) URL for a {item['verdict']} claim")
    elif not isinstance(url, str):
        violations.append(f"claims[{i}].source_url must be a string")
    return violations


def check(data) -> list[str]:
    if not isinstance(data, dict) or set(data) != {"claims", "corrections"}:
        return ["top level must be an object with exactly claims and corrections"]
    violations = []
    claims = data["claims"]
    if not isinstance(claims, list) or not claims:
        violations.append("claims must be a non-empty list")
        claims = []
    for i, item in enumerate(claims):
        violations.extend(check_claim(i, item))
    corrections = data["corrections"]
    if not isinstance(corrections, int) or isinstance(corrections, bool) or corrections < 0:
        violations.append("corrections must be a non-negative integer")
    else:
        corrected = sum(
            1 for c in claims if isinstance(c, dict) and c.get("verdict") == "corrected"
        )
        if corrections != corrected:
            violations.append(
                f"corrections is {corrections} but {corrected} claim(s) have verdict corrected"
            )
    return violations


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__.strip(), file=sys.stderr)
        return 2
    try:
        with open(sys.argv[1], encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"cannot read {sys.argv[1]}: {exc}")
        return 1
    violations = check(data)
    if violations:
        print("\n".join(violations))
        print(f"FAIL: {len(violations)} violation(s).")
        return 1
    print("OK: fact_check.json satisfies the contract.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
